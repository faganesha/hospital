 @extends('layouts.main')

 @section('title')
 Home
 @endsection

 @section('content')

 <body>

    <!-- ========================================= Start Hero -->

    <section  id="skriningMandiri" name='skriningMandiri' class="hero section-padding bg-gray" data-scroll-index="1" style="padding: 20px">
        <div class="container">
            <div class="row">

                <div class="offset-lg-1 col-lg-10">
                    <div class="intro text-center mb-20">
                        <h3>Daftar Tes Kesehatan Jiwa Daring</h3>
                        <p style="color: black">Scan barcode ini untuk melakukan konsultasi via aplikasi Line</p>
                    </div>
                </div>
               
            </div>
             <div class="text-center">
                    <img  class="rounded mx-auto d-block" style="width: 30%" src="img/unnamed.png">
                </div>
        </div>
    </section>

    <!-- End Hero =========================================== -->




    @endsection